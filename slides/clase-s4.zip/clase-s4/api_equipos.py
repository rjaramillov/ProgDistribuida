# api_equipos.py — Ejemplo de referencia de la Unidad III, Sesión 4
# Programación Distribuida · Facultad de Telemática · Universidad de Colima
#
# El CRUD de equipos de la sesión 3 (SQLite + OpenAPI), ahora con:
#   1. Contraseñas guardadas con hash (bcrypt), nunca en texto plano.
#   2. POST /login que entrega un token JWT firmado.
#   3. Roles: solo el "encargado" da de alta, cambia o borra equipos (si no, 403).
#   4. Préstamos con dueño: cada alumno solo ve y cancela LOS SUYOS (ticket SEC-311).
#
# Cómo correrla:
#   pip install fastapi uvicorn pyjwt bcrypt
#   uvicorn api_equipos:app --reload
#   http://127.0.0.1:8000/docs   (botón "Authorize" para pegar el token)
#
# Usuarios de prueba (se crean solos la primera vez):
#   encargado / encargado123   rol: encargado
#   ana       / ana12345       rol: alumno
#   beto      / beto12345      rol: alumno

import os
import sqlite3
from datetime import datetime, timedelta, timezone
from typing import List, Literal

import bcrypt
import jwt
from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, Response
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field

app = FastAPI(
    title="Préstamo de equipo del laboratorio",
    version="4.0",
    description="CRUD de equipos con SQLite, login con JWT, roles y préstamos con dueño. "
                "Todos los errores responden {\"error\", \"detalles\"}.",
)

BD = "equipos.db"
# La clave para FIRMAR los tokens. En producción sale de una variable de entorno y nunca se sube a GitHub.
SECRETO = os.environ.get("JWT_SECRETO", "clave-de-desarrollo-cambiala-en-produccion-2026")
MINUTOS_TOKEN = 30


# ============================================================
# 1. LA BASE DE DATOS
# ============================================================

def conectar():
    con = sqlite3.connect(BD)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


def hash_de(clave: str) -> str:
    # bcrypt agrega una "sal" aleatoria: la misma clave da un hash distinto cada vez
    return bcrypt.hashpw(clave.encode(), bcrypt.gensalt(rounds=12)).decode()


def preparar_bd():
    with conectar() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS equipos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL, tipo TEXT NOT NULL,
            inventario TEXT NOT NULL UNIQUE,
            estado TEXT NOT NULL DEFAULT 'disponible')""")
        con.execute("""CREATE TABLE IF NOT EXISTS usuarios (
            usuario TEXT PRIMARY KEY,
            clave_hash TEXT NOT NULL,              -- el hash, NUNCA la clave
            rol TEXT NOT NULL CHECK (rol IN ('encargado', 'alumno')))""")
        con.execute("""CREATE TABLE IF NOT EXISTS prestamos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            equipo_id INTEGER NOT NULL REFERENCES equipos(id),
            usuario TEXT NOT NULL REFERENCES usuarios(usuario),   -- el DUEÑO del préstamo
            fecha TEXT NOT NULL)""")
        if con.execute("SELECT COUNT(*) FROM usuarios").fetchone()[0] == 0:
            for u, c, r in [("encargado", "encargado123", "encargado"),
                            ("ana", "ana12345", "alumno"), ("beto", "beto12345", "alumno")]:
                con.execute("INSERT INTO usuarios VALUES (?, ?, ?)", (u, hash_de(c), r))
        if con.execute("SELECT COUNT(*) FROM equipos").fetchone()[0] == 0:
            con.execute("INSERT INTO equipos (nombre, tipo, inventario) VALUES "
                        "('Multímetro Fluke 115', 'multimetro', 'LAB-001'), ('Arduino UNO R3', 'arduino', 'LAB-002')")


preparar_bd()


# ============================================================
# 2. MODELOS Y FORMATO DE ERROR (igual que en las sesiones 2 y 3)
# ============================================================

class EquipoNuevo(BaseModel):
    nombre: str = Field(..., min_length=2, max_length=60, examples=["Multímetro Fluke 115"])
    tipo: Literal["multimetro", "arduino", "osciloscopio", "fuente"]
    inventario: str = Field(..., pattern=r"^LAB-\d{3}$", examples=["LAB-001"])


class Equipo(EquipoNuevo):
    id: int
    estado: Literal["disponible", "prestado", "reparacion"]


class Credenciales(BaseModel):
    usuario: str = Field(..., examples=["ana"])
    clave: str = Field(..., max_length=72, examples=["ana12345"])   # bcrypt usa hasta 72 bytes


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expira_en_segundos: int


class PrestamoNuevo(BaseModel):
    equipo_id: int = Field(..., examples=[1])


class Prestamo(BaseModel):
    id: int
    equipo_id: int
    usuario: str
    fecha: str


class ErrorRespuesta(BaseModel):
    error: str
    detalles: List[str] = []


def E(codigo, texto):
    return {codigo: {"model": ErrorRespuesta, "description": texto}}


E400, E404, E409, E422 = E(400, "El cuerpo no es un JSON válido"), E(404, "No existe"), \
    E(409, "Choca con lo que ya hay"), E(422, "Los datos no cumplen las reglas")
E401 = E(401, "Falta el token, es falso o ya expiró")
E403 = E(403, "Tu rol no tiene permiso para esta operación")


def error(codigo, mensaje, detalles=None, encabezados=None):
    return JSONResponse(status_code=codigo, content={"error": mensaje, "detalles": detalles or []},
                        headers=encabezados)


@app.exception_handler(HTTPException)
async def error_http(request: Request, exc: HTTPException):
    return error(exc.status_code, exc.detail, encabezados=exc.headers)


@app.exception_handler(RequestValidationError)
async def error_validacion(request: Request, exc: RequestValidationError):
    errores = exc.errors()
    if any(e["type"] == "json_invalid" for e in errores):
        return error(400, "El cuerpo no es un JSON válido")
    return error(422, "Los datos no son válidos",
                 [f"{'.'.join(str(x) for x in e['loc'][1:])}: {e['msg']}" for e in errores])


@app.exception_handler(Exception)
async def error_interno(request: Request, exc: Exception):
    return error(500, "Error interno del servidor")


# ============================================================
# 3. AUTENTICACIÓN: ¿QUIÉN ERES?  (login -> token -> verificar el token en cada petición)
# ============================================================

@app.post("/login", response_model=Token, responses=E(401, "Usuario o clave incorrectos"),
          tags=["sesión"], summary="Entrar: cambia usuario y clave por un token")
def login(c: Credenciales):
    with conectar() as con:
        fila = con.execute("SELECT * FROM usuarios WHERE usuario = ?", (c.usuario,)).fetchone()
    # Mismo mensaje si no existe el usuario o si la clave está mal: no le digas al atacante cuál falló
    if fila is None or not bcrypt.checkpw(c.clave.encode(), fila["clave_hash"].encode()):
        raise HTTPException(401, "Usuario o clave incorrectos")
    ahora = datetime.now(timezone.utc)
    datos = {"sub": fila["usuario"], "rol": fila["rol"],           # lo que el token "dice" de ti
             "iat": ahora, "exp": ahora + timedelta(minutes=MINUTOS_TOKEN)}
    token = jwt.encode(datos, SECRETO, algorithm="HS256")          # firmado con la clave del servidor
    return {"access_token": token, "token_type": "bearer", "expira_en_segundos": MINUTOS_TOKEN * 60}


bearer = HTTPBearer(auto_error=False)   # lee el encabezado  Authorization: Bearer <token>
SIN_SESION = {"WWW-Authenticate": "Bearer"}


def usuario_actual(cred: HTTPAuthorizationCredentials = Depends(bearer)) -> dict:
    if cred is None:
        raise HTTPException(401, "Falta el token: inicia sesión en POST /login", headers=SIN_SESION)
    try:
        datos = jwt.decode(cred.credentials, SECRETO, algorithms=["HS256"])   # revisa firma y expiración
    except jwt.ExpiredSignatureError:
        raise HTTPException(401, "El token ya expiró: inicia sesión otra vez", headers=SIN_SESION)
    except jwt.InvalidTokenError:
        raise HTTPException(401, "El token no es válido (¿lo modificaste?)", headers=SIN_SESION)
    return {"usuario": datos["sub"], "rol": datos["rol"]}


# ============================================================
# 4. AUTORIZACIÓN: ¿QUÉ PUEDES HACER?  (rol -> 403)
# ============================================================

def solo_encargado(yo: dict = Depends(usuario_actual)) -> dict:
    if yo["rol"] != "encargado":
        raise HTTPException(403, f"Tu rol ({yo['rol']}) no puede hacer esto: solo el encargado")
    return yo


@app.get("/yo", tags=["sesión"], responses=E401, summary="¿Quién dice el token que soy?")
def quien_soy(yo: dict = Depends(usuario_actual)):
    return yo


# ============================================================
# 5. EQUIPOS: consultar es público; cambiar es solo del encargado
# ============================================================

def buscar_equipo(con, equipo_id: int):
    fila = con.execute("SELECT * FROM equipos WHERE id = ?", (equipo_id,)).fetchone()
    if fila is None:
        raise HTTPException(404, f"No existe el equipo {equipo_id}")
    return dict(fila)


@app.get("/equipos", response_model=List[Equipo], tags=["equipos"], summary="Listar equipos (público)")
def listar():
    with conectar() as con:
        return [dict(f) for f in con.execute("SELECT * FROM equipos ORDER BY id")]


@app.get("/equipos/{equipo_id}", response_model=Equipo, responses=E404, tags=["equipos"],
         summary="Consultar un equipo (público)")
def consultar(equipo_id: int):
    with conectar() as con:
        return buscar_equipo(con, equipo_id)


@app.post("/equipos", status_code=201, response_model=Equipo,
          responses={**E400, **E401, **E403, **E409, **E422}, tags=["equipos"], summary="Crear (encargado)")
def crear(datos: EquipoNuevo, response: Response, yo: dict = Depends(solo_encargado)):
    with conectar() as con:
        try:
            cur = con.execute("INSERT INTO equipos (nombre, tipo, inventario) VALUES (?, ?, ?)",
                              (datos.nombre, datos.tipo, datos.inventario))
        except sqlite3.IntegrityError:
            raise HTTPException(409, f"Ya existe un equipo con inventario {datos.inventario}")
        response.headers["Location"] = f"/equipos/{cur.lastrowid}"
        return buscar_equipo(con, cur.lastrowid)


@app.put("/equipos/{equipo_id}", response_model=Equipo,
         responses={**E400, **E401, **E403, **E404, **E409, **E422}, tags=["equipos"], summary="Reemplazar (encargado)")
def reemplazar(equipo_id: int, datos: EquipoNuevo, yo: dict = Depends(solo_encargado)):
    with conectar() as con:
        buscar_equipo(con, equipo_id)
        try:
            con.execute("UPDATE equipos SET nombre = ?, tipo = ?, inventario = ? WHERE id = ?",
                        (datos.nombre, datos.tipo, datos.inventario, equipo_id))
        except sqlite3.IntegrityError:
            raise HTTPException(409, f"Ya existe un equipo con inventario {datos.inventario}")
        return buscar_equipo(con, equipo_id)


@app.delete("/equipos/{equipo_id}", status_code=204, responses={**E401, **E403, **E404, **E409},
            tags=["equipos"], summary="Borrar (encargado)")
def borrar(equipo_id: int, yo: dict = Depends(solo_encargado)):
    with conectar() as con:
        if buscar_equipo(con, equipo_id)["estado"] == "prestado":
            raise HTTPException(409, "No se puede borrar un equipo que está prestado")
        con.execute("DELETE FROM equipos WHERE id = ?", (equipo_id,))
    return Response(status_code=204)


# ============================================================
# 6. PRÉSTAMOS: cada uno tiene DUEÑO  (ticket SEC-311 · OWASP API1:2023)
#    El dueño sale del TOKEN, nunca de lo que mande el cliente.
# ============================================================

def buscar_prestamo(con, prestamo_id: int, yo: dict):
    if yo["rol"] == "encargado":
        fila = con.execute("SELECT * FROM prestamos WHERE id = ?", (prestamo_id,)).fetchone()
    else:
        # la línea que corrige SEC-311: además del id, el préstamo tiene que ser MÍO
        fila = con.execute("SELECT * FROM prestamos WHERE id = ? AND usuario = ?",
                           (prestamo_id, yo["usuario"])).fetchone()
    if fila is None:
        # 404 y no 403: no le confirmamos a nadie que ese préstamo existe
        raise HTTPException(404, f"No existe el préstamo {prestamo_id}")
    return dict(fila)


@app.get("/prestamos", response_model=List[Prestamo], responses=E401, tags=["préstamos"],
         summary="Mis préstamos (el encargado ve todos)")
def mis_prestamos(yo: dict = Depends(usuario_actual)):
    with conectar() as con:
        if yo["rol"] == "encargado":
            filas = con.execute("SELECT * FROM prestamos ORDER BY id")
        else:
            filas = con.execute("SELECT * FROM prestamos WHERE usuario = ? ORDER BY id", (yo["usuario"],))
        return [dict(f) for f in filas]


@app.post("/prestamos", status_code=201, response_model=Prestamo,
          responses={**E400, **E401, **E404, **E409, **E422}, tags=["préstamos"], summary="Pedir un equipo prestado")
def pedir_prestamo(datos: PrestamoNuevo, response: Response, yo: dict = Depends(usuario_actual)):
    with conectar() as con:
        if buscar_equipo(con, datos.equipo_id)["estado"] != "disponible":
            raise HTTPException(409, f"El equipo {datos.equipo_id} no está disponible")
        cur = con.execute("INSERT INTO prestamos (equipo_id, usuario, fecha) VALUES (?, ?, ?)",
                          (datos.equipo_id, yo["usuario"], datetime.now().isoformat(timespec="seconds")))
        con.execute("UPDATE equipos SET estado = 'prestado' WHERE id = ?", (datos.equipo_id,))
        response.headers["Location"] = f"/prestamos/{cur.lastrowid}"
        return buscar_prestamo(con, cur.lastrowid, yo)


@app.get("/prestamos/{prestamo_id}", response_model=Prestamo, responses={**E401, **E404}, tags=["préstamos"],
         summary="Consultar un préstamo (solo el dueño o el encargado)")
def consultar_prestamo(prestamo_id: int, yo: dict = Depends(usuario_actual)):
    with conectar() as con:
        return buscar_prestamo(con, prestamo_id, yo)


@app.delete("/prestamos/{prestamo_id}", status_code=204, responses={**E401, **E404}, tags=["préstamos"],
            summary="Cancelar o devolver un préstamo (solo el dueño o el encargado)")
def cancelar_prestamo(prestamo_id: int, yo: dict = Depends(usuario_actual)):
    with conectar() as con:
        p = buscar_prestamo(con, prestamo_id, yo)
        con.execute("DELETE FROM prestamos WHERE id = ?", (prestamo_id,))
        con.execute("UPDATE equipos SET estado = 'disponible' WHERE id = ?", (p["equipo_id"],))
    return Response(status_code=204)


# ============================================================
# 7. DEMO DE CLASE: así estaba antes de SEC-311. NUNCA hagan esto.
# ============================================================

@app.get("/demo/prestamo-inseguro/{prestamo_id}", tags=["demo: SEC-311"],
         summary="NO HACER: pide token, pero no revisa de quién es el préstamo")
def prestamo_inseguro(prestamo_id: int, yo: dict = Depends(usuario_actual)):
    with conectar() as con:
        fila = con.execute("SELECT * FROM prestamos WHERE id = ?", (prestamo_id,)).fetchone()   # falta: AND usuario = ?
    if fila is None:
        raise HTTPException(404, f"No existe el préstamo {prestamo_id}")
    return {"lo_pidio": yo["usuario"], "prestamo": dict(fila)}
