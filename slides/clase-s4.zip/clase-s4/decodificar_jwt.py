# decodificar_jwt.py — Lee lo que trae un token JWT (Unidad III, Sesión 4)
# Uso:
#   python decodificar_jwt.py <token>                      muestra sus 3 partes
#   python decodificar_jwt.py <token> --rol encargado      cambia el rol (sin poder firmarlo de nuevo)
#   python decodificar_jwt.py <token> --romper-firma       cambia un carácter de la firma
# No necesita instalar nada. NO verifica la firma: para eso hace falta la clave secreta del servidor.
import base64
import json
import sys
from datetime import datetime

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass


def b64_a_texto(parte):
    return base64.urlsafe_b64decode(parte + "=" * (-len(parte) % 4)).decode("utf-8")


def texto_a_b64(texto):
    return base64.urlsafe_b64encode(texto.encode("utf-8")).decode().rstrip("=")


if len(sys.argv) < 2 or sys.argv[1].count(".") != 2:
    sys.exit("Uso: python decodificar_jwt.py <token>   (un JWT tiene 3 partes separadas por puntos)")

token = sys.argv[1]
cabecera, datos, firma = token.split(".")
d = json.loads(b64_a_texto(datos))

if "--romper-firma" in sys.argv:
    nueva = firma[:-2] + ("A" if firma[-2] != "A" else "B") + firma[-1]
    print("Cambié un solo carácter de la firma (el penúltimo).")
    print("Token con la firma rota:")
    print(f"{cabecera}.{datos}.{nueva}")
elif "--rol" in sys.argv:
    rol = sys.argv[sys.argv.index("--rol") + 1]
    print("Datos originales: " + json.dumps(d, ensure_ascii=False))
    d["rol"] = rol
    print("Datos cambiados:  " + json.dumps(d, ensure_ascii=False))
    print("Conservé la firma original: no tengo la clave secreta para firmar otra vez.")
    print("Token falsificado:")
    print(f"{cabecera}.{texto_a_b64(json.dumps(d, separators=(',', ':')))}.{firma}")
else:
    print("El token tiene 3 partes separadas por puntos:\n")
    print("1) CABECERA: cómo se firmó")
    print("   " + b64_a_texto(cabecera) + "\n")
    print("2) DATOS (payload): cualquiera los puede leer, NO están cifrados")
    print("   " + json.dumps(d, ensure_ascii=False))
    for k, nombre in (("iat", "emitido"), ("exp", "expira")):
        if isinstance(d.get(k), (int, float)):
            print(f"   {k} = {nombre} el {datetime.fromtimestamp(d[k]).strftime('%d/%m/%Y %H:%M:%S')}")
    print("\n3) FIRMA: solo la puede generar quien tiene la clave secreta (el servidor)")
    print("   " + firma)
