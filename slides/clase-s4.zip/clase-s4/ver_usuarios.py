# ver_usuarios.py — Muestra cómo quedan guardadas las contraseñas en equipos.db (Unidad III, Sesión 4)
# Uso:
#   python ver_usuarios.py              la tabla usuarios tal como está en la base
#   python ver_usuarios.py ana12345     la misma clave convertida en hash dos veces, y cómo se comprueba
import sqlite3
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

if len(sys.argv) > 1:
    import bcrypt
    clave = sys.argv[1].encode()
    h1 = bcrypt.hashpw(clave, bcrypt.gensalt(rounds=12)).decode()
    h2 = bcrypt.hashpw(clave, bcrypt.gensalt(rounds=12)).decode()
    print(f"Hash 1 de '{sys.argv[1]}': {h1}")
    print(f"Hash 2 de '{sys.argv[1]}': {h2}")
    print("Son distintos: cada hash lleva una sal aleatoria (los 22 caracteres después de $2b$12$).")
    print(f"¿'{sys.argv[1]}' corresponde al hash 1?  {bcrypt.checkpw(clave, h1.encode())}")
    print(f"¿'otra-clave' corresponde al hash 1?  {bcrypt.checkpw(b'otra-clave', h1.encode())}")
else:
    con = sqlite3.connect("equipos.db")
    print(f"{'usuario':<10} {'rol':<10} clave_hash")
    for u, r, h in con.execute("SELECT usuario, rol, clave_hash FROM usuarios ORDER BY rol DESC, usuario"):
        print(f"{u:<10} {r:<10} {h}")
    print("\nNinguna clave está en texto. $2b$ = bcrypt · 12 = costo · luego 22 de sal y 31 del hash.")
