# api_memoria.py — La API de equipos de la sesión 2 (datos EN MEMORIA)
# Se incluye en la sesión 3 solo para comparar: al reiniciarla, sus datos se pierden.
# El puente la arranca en el puerto 8001:  uvicorn api_memoria:app --port 8001
#
# (Archivo original: api_equipos.py, Unidad III, Sesión 2)
# Programación Distribuida · Facultad de Telemática · Universidad de Colima
#
# El ejemplo resuelto de la sesión 1, ya programado:
# préstamo de equipo del laboratorio, con CRUD y validación.
#
# Cómo correrla:
#   pip install fastapi uvicorn
#   uvicorn api_equipos:app --reload
#   http://127.0.0.1:8000/docs
#
# Los datos viven en memoria (la base de datos llega en la sesión 3).

from typing import Literal, Optional

from fastapi import Body, FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel, Field

app = FastAPI(title="Préstamo de equipo del laboratorio", version="2.0")


# ============================================================
# 1. LAS REGLAS DE VALIDACIÓN: qué datos aceptamos
#    Si algo no cumple, FastAPI responde 422 por nosotros.
# ============================================================

TIPOS = Literal["multimetro", "arduino", "osciloscopio", "fuente"]
ESTADOS = Literal["disponible", "prestado", "reparacion"]


class EquipoNuevo(BaseModel):                      # POST y PUT: el equipo completo
    nombre: str = Field(..., min_length=2, max_length=60, examples=["Multímetro Fluke 115"])
    tipo: TIPOS = Field(..., examples=["multimetro"])
    inventario: str = Field(..., pattern=r"^LAB-\d{3}$", examples=["LAB-001"])


class EquipoCambios(BaseModel):                    # PATCH: solo lo que cambia
    nombre: Optional[str] = Field(None, min_length=2, max_length=60)
    estado: Optional[ESTADOS] = None


class PrestamoNuevo(BaseModel):
    equipo_id: int = Field(..., gt=0)
    matricula: str = Field(..., pattern=r"^\d{8}$", examples=["20201234"])


class Devolucion(BaseModel):
    devuelto: Literal[True]                        # solo se acepta {"devuelto": true}


# ============================================================
# 2. LOS DATOS (en memoria por ahora)
# ============================================================

equipos = {
    1: {"id": 1, "nombre": "Multímetro Fluke 115", "tipo": "multimetro", "inventario": "LAB-001", "estado": "disponible"},
    2: {"id": 2, "nombre": "Arduino UNO R3", "tipo": "arduino", "inventario": "LAB-002", "estado": "disponible"},
}
prestamos = {}
siguiente = {"equipo": 3, "prestamo": 1}


# ============================================================
# 3. UN SOLO FORMATO PARA TODOS LOS ERRORES
#    Siempre: {"error": "...", "detalles": [...]}
# ============================================================

def error(codigo, mensaje, detalles=None):
    return JSONResponse(status_code=codigo, content={"error": mensaje, "detalles": detalles or []})


@app.exception_handler(HTTPException)               # 404, 409… que lanzamos nosotros
async def error_http(request: Request, exc: HTTPException):
    return error(exc.status_code, exc.detail)


@app.exception_handler(RequestValidationError)      # los datos no cumplen el modelo
async def error_validacion(request: Request, exc: RequestValidationError):
    errores = exc.errors()
    if any(e["type"] == "json_invalid" for e in errores):        # ni siquiera es JSON
        return error(400, "El cuerpo no es un JSON válido")
    detalles = [f"{'.'.join(str(x) for x in e['loc'][1:])}: {e['msg']}" for e in errores]
    return error(422, "Los datos no son válidos", detalles)


@app.exception_handler(Exception)                   # un bug nuestro: nunca debería pasar
async def error_interno(request: Request, exc: Exception):
    return error(500, "Error interno del servidor")


def buscar_equipo(equipo_id: int):
    if equipo_id not in equipos:
        raise HTTPException(404, f"No existe el equipo {equipo_id}")
    return equipos[equipo_id]


def inventario_repetido(inventario: str, excepto: int = 0):
    return any(e["inventario"] == inventario and e["id"] != excepto for e in equipos.values())


# ============================================================
# 4. EL CRUD DE EQUIPOS
# ============================================================

@app.get("/equipos", tags=["equipos"])
def listar_equipos():
    return list(equipos.values())


@app.get("/equipos/{equipo_id}", tags=["equipos"])
def consultar_equipo(equipo_id: int):
    return buscar_equipo(equipo_id)


@app.post("/equipos", status_code=201, tags=["equipos"])
def crear_equipo(datos: EquipoNuevo, response: Response):
    if inventario_repetido(datos.inventario):                       # regla del negocio
        raise HTTPException(409, f"Ya existe un equipo con inventario {datos.inventario}")
    nuevo = {"id": siguiente["equipo"], **datos.model_dump(), "estado": "disponible"}
    equipos[nuevo["id"]] = nuevo
    siguiente["equipo"] += 1
    response.headers["Location"] = f"/equipos/{nuevo['id']}"
    return nuevo


@app.put("/equipos/{equipo_id}", tags=["equipos"])
def reemplazar_equipo(equipo_id: int, datos: EquipoNuevo):
    actual = buscar_equipo(equipo_id)
    if inventario_repetido(datos.inventario, excepto=equipo_id):
        raise HTTPException(409, f"Ya existe un equipo con inventario {datos.inventario}")
    equipos[equipo_id] = {"id": equipo_id, **datos.model_dump(), "estado": actual["estado"]}
    return equipos[equipo_id]


@app.patch("/equipos/{equipo_id}", tags=["equipos"])
def modificar_equipo(equipo_id: int, cambios: EquipoCambios):
    equipo = buscar_equipo(equipo_id)
    equipo.update(cambios.model_dump(exclude_unset=True))
    return equipo


@app.delete("/equipos/{equipo_id}", status_code=204, tags=["equipos"])
def borrar_equipo(equipo_id: int):
    equipo = buscar_equipo(equipo_id)
    if equipo["estado"] == "prestado":                              # regla del negocio
        raise HTTPException(409, "No se puede borrar un equipo que está prestado")
    del equipos[equipo_id]
    return Response(status_code=204)


# ============================================================
# 5. PRÉSTAMOS: aquí viven las reglas del negocio (409)
# ============================================================

@app.post("/prestamos", status_code=201, tags=["préstamos"])
def crear_prestamo(datos: PrestamoNuevo, response: Response):
    if datos.equipo_id not in equipos:                              # no existe, pero viene en el cuerpo
        return error(422, "Los datos no son válidos", [f"equipo_id: no existe el equipo {datos.equipo_id}"])
    equipo = equipos[datos.equipo_id]
    if equipo["estado"] != "disponible":                            # regla del negocio
        raise HTTPException(409, f"El equipo {equipo['id']} no está disponible ({equipo['estado']})")
    p = {"id": siguiente["prestamo"], **datos.model_dump(), "devuelto": False}
    prestamos[p["id"]] = p
    siguiente["prestamo"] += 1
    equipo["estado"] = "prestado"
    response.headers["Location"] = f"/prestamos/{p['id']}"
    return p


@app.get("/prestamos/{prestamo_id}", tags=["préstamos"])
def consultar_prestamo(prestamo_id: int):
    if prestamo_id not in prestamos:
        raise HTTPException(404, f"No existe el préstamo {prestamo_id}")
    return prestamos[prestamo_id]


@app.patch("/prestamos/{prestamo_id}", tags=["préstamos"])
def devolver(prestamo_id: int, datos: Devolucion):                  # idempotente: "déjalo devuelto"
    p = consultar_prestamo(prestamo_id)
    p["devuelto"] = True
    equipos[p["equipo_id"]]["estado"] = "disponible"
    return p


# ============================================================
# 6. DEMO DE CLASE: el mismo POST, pero SIN validar
#    Acepta cualquier cosa. Solo para ver qué pasa.
# ============================================================

sin_validar = []


@app.post("/sin-validar/equipos", status_code=201, tags=["demo: sin validación"])
def crear_sin_validar(datos: dict = Body(...)):
    sin_validar.append(datos)
    return datos


@app.get("/sin-validar/equipos", tags=["demo: sin validación"])
def listar_sin_validar():
    return sin_validar


@app.get("/sin-validar/reporte", tags=["demo: sin validación"])
def reporte_sin_validar():
    # Un reporte que confía en los datos: suma cuántas piezas hay de cada equipo
    return {"total_piezas": sum(e["cantidad"] for e in sin_validar)}
