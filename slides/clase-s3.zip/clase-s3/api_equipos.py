# api_equipos.py — Ejemplo de referencia de la Unidad III, Sesión 3
# Programación Distribuida · Facultad de Telemática · Universidad de Colima
#
# El CRUD de equipos de la sesión 2, ahora:
#   1. guardando en una base de datos SQLite (equipos.db), con consultas parametrizadas;
#   2. documentado con OpenAPI, incluidos los errores (FastAPI lo genera en /docs y /openapi.json).
#
# Cómo correrla:
#   pip install fastapi uvicorn
#   uvicorn api_equipos:app --reload
#   http://127.0.0.1:8000/docs
#
# sqlite3 viene incluido en Python: no hay que instalar nada más.

import sqlite3
from typing import List, Literal, Optional

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel, Field

app = FastAPI(
    title="Préstamo de equipo del laboratorio",
    version="3.0",
    description="CRUD de equipos con SQLite. Todos los errores responden {\"error\", \"detalles\"}.",
)

BD = "equipos.db"


# ============================================================
# 1. LA BASE DE DATOS
# ============================================================

def conectar():
    con = sqlite3.connect(BD)
    con.row_factory = sqlite3.Row          # cada fila se puede leer como diccionario
    return con


def preparar_bd():
    with conectar() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS equipos (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre     TEXT NOT NULL,
                tipo       TEXT NOT NULL,
                inventario TEXT NOT NULL UNIQUE,
                estado     TEXT NOT NULL DEFAULT 'disponible'
            )""")
        con.execute("""
            CREATE TABLE IF NOT EXISTS usuarios (
                usuario TEXT PRIMARY KEY,
                clave   TEXT NOT NULL
            )""")
        con.execute("INSERT OR IGNORE INTO usuarios VALUES ('admin', 'secreta123')")


preparar_bd()


# ============================================================
# 2. LAS REGLAS (igual que en la sesión 2) Y EL FORMATO DE ERROR
# ============================================================

class EquipoNuevo(BaseModel):
    nombre: str = Field(..., min_length=2, max_length=60, examples=["Multímetro Fluke 115"])
    tipo: Literal["multimetro", "arduino", "osciloscopio", "fuente"]
    inventario: str = Field(..., pattern=r"^LAB-\d{3}$", examples=["LAB-001"])


class Equipo(EquipoNuevo):
    id: int
    estado: Literal["disponible", "prestado", "reparacion"]


class ErrorRespuesta(BaseModel):                     # el formato de error, documentado
    error: str
    detalles: List[str] = []


E404 = {404: {"model": ErrorRespuesta, "description": "No existe el equipo"}}
E409 = {409: {"model": ErrorRespuesta, "description": "Choca con lo que ya hay (inventario repetido o equipo prestado)"}}
E422 = {422: {"model": ErrorRespuesta, "description": "Los datos no cumplen las reglas"}}
E400 = {400: {"model": ErrorRespuesta, "description": "El cuerpo no es un JSON válido"}}


def error(codigo, mensaje, detalles=None):
    return JSONResponse(status_code=codigo, content={"error": mensaje, "detalles": detalles or []})


@app.exception_handler(HTTPException)
async def error_http(request: Request, exc: HTTPException):
    return error(exc.status_code, exc.detail)


@app.exception_handler(RequestValidationError)
async def error_validacion(request: Request, exc: RequestValidationError):
    errores = exc.errors()
    if any(e["type"] == "json_invalid" for e in errores):
        return error(400, "El cuerpo no es un JSON válido")
    detalles = [f"{'.'.join(str(x) for x in e['loc'][1:])}: {e['msg']}" for e in errores]
    return error(422, "Los datos no son válidos", detalles)


@app.exception_handler(Exception)
async def error_interno(request: Request, exc: Exception):
    return error(500, "Error interno del servidor")


def buscar(con, equipo_id: int):
    fila = con.execute("SELECT * FROM equipos WHERE id = ?", (equipo_id,)).fetchone()
    if fila is None:
        raise HTTPException(404, f"No existe el equipo {equipo_id}")
    return dict(fila)


# ============================================================
# 3. EL CRUD, AHORA CON SQL
#    Los datos del cliente SIEMPRE van como parámetros (?), nunca pegados al texto del SQL.
# ============================================================

@app.get("/equipos", response_model=List[Equipo], tags=["equipos"], summary="Listar equipos")
def listar():
    with conectar() as con:
        return [dict(f) for f in con.execute("SELECT * FROM equipos ORDER BY id")]


@app.get("/equipos/{equipo_id}", response_model=Equipo, responses=E404, tags=["equipos"], summary="Consultar un equipo")
def consultar(equipo_id: int):
    with conectar() as con:
        return buscar(con, equipo_id)


@app.post("/equipos", status_code=201, response_model=Equipo, responses={**E400, **E409, **E422},
          tags=["equipos"], summary="Crear un equipo")
def crear(datos: EquipoNuevo, response: Response):
    with conectar() as con:
        try:
            cur = con.execute(
                "INSERT INTO equipos (nombre, tipo, inventario) VALUES (?, ?, ?)",
                (datos.nombre, datos.tipo, datos.inventario),
            )
        except sqlite3.IntegrityError:                  # la columna inventario es UNIQUE
            raise HTTPException(409, f"Ya existe un equipo con inventario {datos.inventario}")
        response.headers["Location"] = f"/equipos/{cur.lastrowid}"
        return buscar(con, cur.lastrowid)


@app.put("/equipos/{equipo_id}", response_model=Equipo, responses={**E400, **E404, **E409, **E422},
         tags=["equipos"], summary="Reemplazar un equipo completo")
def reemplazar(equipo_id: int, datos: EquipoNuevo):
    with conectar() as con:
        buscar(con, equipo_id)
        try:
            con.execute(
                "UPDATE equipos SET nombre = ?, tipo = ?, inventario = ? WHERE id = ?",
                (datos.nombre, datos.tipo, datos.inventario, equipo_id),
            )
        except sqlite3.IntegrityError:
            raise HTTPException(409, f"Ya existe un equipo con inventario {datos.inventario}")
        return buscar(con, equipo_id)


@app.delete("/equipos/{equipo_id}", status_code=204, responses={**E404, **E409},
            tags=["equipos"], summary="Borrar un equipo")
def borrar(equipo_id: int):
    with conectar() as con:
        if buscar(con, equipo_id)["estado"] == "prestado":
            raise HTTPException(409, "No se puede borrar un equipo que está prestado")
        con.execute("DELETE FROM equipos WHERE id = ?", (equipo_id,))
    return Response(status_code=204)


# ============================================================
# 4. DEMO DE CLASE: inyección SQL
#    El mismo login, armado de dos formas. NUNCA hagan el primero.
# ============================================================

class Credenciales(BaseModel):
    usuario: str
    clave: str


@app.post("/demo/login-inseguro", tags=["demo: inyección SQL"], summary="NO HACER: SQL armado pegando texto")
def login_inseguro(c: Credenciales):
    sql = f"SELECT usuario FROM usuarios WHERE usuario = '{c.usuario}' AND clave = '{c.clave}'"
    with conectar() as con:
        fila = con.execute(sql).fetchone()
    return {"sql_que_se_ejecuto": sql, "entraste_como": fila["usuario"] if fila else None}


@app.post("/demo/login-seguro", tags=["demo: inyección SQL"], summary="Correcto: consulta parametrizada")
def login_seguro(c: Credenciales):
    sql = "SELECT usuario FROM usuarios WHERE usuario = ? AND clave = ?"
    with conectar() as con:
        fila = con.execute(sql, (c.usuario, c.clave)).fetchone()
    return {"sql_que_se_ejecuto": sql, "parametros": [c.usuario, c.clave],
            "entraste_como": fila["usuario"] if fila else None}
